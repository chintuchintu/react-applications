var express = require('express');
var mysql = require('mysql');


var router = express.Router();

/*
create database bank;

use bank;

create table account(accno int primary key,name text,balance double,doc date);

insert into account values(101,'pradeep chinchole',72000.444,'2011-11-11');
insert into account values(102,'sachin chinchole',72000.444,'2012-11-11');
insert into account values(103,'devansh chinchole',52000.444,'2013-11-11');
insert into account values(104,'prachitee chinchole',52000.444,'2014-11-11');
insert into account values(105,'sumit kakkar',32000.444,'2015-11-11');


*/


//establish the connection with mysql database

var connection=mysql.createConnection({
    host:"localhost",
    port:3306,
    database:"bank",
    user:"root",
    password:"admin"
},function(err){
    if(err)
      console.log("Problem in establishing the connection with mysql");
     else
     console.log("Connectionn established with mysql");
 });



/* GET all accounts */
router.get('/accounts', function(req, res, next) {
    
    connection.query("SELECT * FROM ACCOUNT",function(err,data){
     if(err)
     return res.send(""+err);
  
     res.json(data);
    });
  
});


/* GET account by accno */
router.get('/accounts/:accno', function(req, res, next) {
    var accno=parseInt(req.params.accno);

    connection.query("SELECT * FROM ACCOUNT WHERE ACCNO=?",[accno],function(err,data){
        if(err)
        return res.send(""+err);
     
        res.json(data[0]);
       });
     

});
  

/* delete account by accno */
router.delete('/accounts/:accno', function(req, res, next) {
    var accno=parseInt(req.params.accno);

    connection.query("DELETE FROM ACCOUNT WHERE ACCNO=?",[accno],function(err,data){
        if(err)
        return res.send(""+err);
     
        connection.query("SELECT * FROM ACCOUNT",function(err,data){
            if(err)
            return res.send(""+err);
         
            res.json(data);
           });
         


       });
     
    


});

/* update account by accno */
router.put('/accounts/:accno', function(req, res, next) {
    var accno=parseInt(req.params.accno);

    var name=req.body.name;
    var balance=parseFloat(req.body.balance);
    var doc=req.body.doc;
    
    
    connection.query("UPDATE ACCOUNT SET NAME=?, BALANCE=?, DOC=? WHERE ACCNO=?",[name,balance,doc,accno],function(err,data){
        if(err)
        return res.send(""+err);
     
        connection.query("SELECT * FROM ACCOUNT",function(err,data){
            if(err)
            return res.send(""+err);
         
            res.json(data);
           });
       });
    
});



/* update account by accno */
router.post('/accounts', function(req, res, next) {
    var account=req.body;

    connection.query("INSERT INTO ACCOUNT SET ?",[account],function(err,data){
        if(err)
        return res.send(""+err);
     
        connection.query("SELECT * FROM ACCOUNT",function(err,data){
            if(err)
            return res.send(""+err);
         
            res.json(data);
           });
       });
    
    
});



module.exports = router;
